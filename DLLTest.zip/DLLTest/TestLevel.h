#pragma once

#define G
#define VG

